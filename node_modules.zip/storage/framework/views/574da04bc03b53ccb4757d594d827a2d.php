<?php $__env->startSection('content'); ?>
<div class="welcome-container">
    <div class="table-details-container">
    <img class="plate" src="<?php echo e(asset('img/plate.svg')); ?>" alt="Logo" class="logo">
    <h3 class="table-number"><?php echo e($table->id); ?></h3>
    </div>
    <div class="menu-navigation-container">
        <a href="#Voorgerechten">Voorgerechten</a>
        <a href="#Hoofdgerechten">Hoofdgerechten</a>
        <a href="#Desserts">Desserts</a>
        <a href="#Dranken">Dranken</a>

    </div>
</div>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('check-location', ['tableId' => $table->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2869631442-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OrderFlow\resources\views/table_order.blade.php ENDPATH**/ ?>
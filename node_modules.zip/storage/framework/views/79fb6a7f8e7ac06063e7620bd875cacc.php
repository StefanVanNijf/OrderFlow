<div class="footer">
    QR Code Terras 2024 rechten
</div><?php /**PATH C:\laragon\www\OrderFlow\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
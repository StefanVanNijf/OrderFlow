<?php $__env->startSection('content'); ?>


<div class="qr-message">
    QR-code succesvol gescand!
</div>

<div class="container">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="category">
            <div class="category-header">
                <h2><?php echo e($category->name); ?></h2>
            </div>
            <div class="items">
                <?php $__currentLoopData = $category->menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="item-info">
                            <div class="item-name"><?php echo e($item->name); ?></div>
                            <div class="item-description"><?php echo e($item->description); ?></div>
                        </div>
                        <div class="item-actions">
                            <div class="item-price">€<?php echo e(number_format($item->price, 2)); ?></div>
                            <button class="add-item-btn" onclick="addToCart(<?php echo e(json_encode($item)); ?>)">&#43;</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="footer">
    @terrasje 2024 rechten
</div>

<script>
    let cart = [];

    function addToCart(item) {
        cart.push(item);
        updateCartPanel();
        updateCartCount();
    }

    function updateCartPanel() {
        const cartPanel = document.querySelector('.cart-panel');
        cartPanel.innerHTML = cart.map(item => `<div>${item.name} - €${item.price}</div>`).join('');
    }

    function updateCartCount() {
        const cartCount = document.getElementById('cart-count');
        cartCount.textContent = cart.length;
    }

    function redirectToCheckout() {
        sessionStorage.setItem('cart', JSON.stringify(cart));
        window.location.href = '/menu/afrekenen';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OrderFlow\resources\views/menu/index.blade.php ENDPATH**/ ?>
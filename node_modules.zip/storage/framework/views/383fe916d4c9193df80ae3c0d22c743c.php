<div wire:poll.5s class="container">
 
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="order">
            <h3>Tafel <?php echo e($order->table->id); ?> - Status: <?php echo e($order->order_status); ?></h3>
            <ul>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->orderedMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($item->menuItem->name); ?> x <?php echo e($item->quantity); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\OrderFlow\resources\views/livewire/tafel-overzicht.blade.php ENDPATH**/ ?>
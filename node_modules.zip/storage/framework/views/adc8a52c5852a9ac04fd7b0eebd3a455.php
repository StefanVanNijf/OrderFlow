<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Terras</title>
    <link rel="icon" href="<?php echo e(asset('img/logo.svg')); ?>" type="image/x-icon">


    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/css/menu.css', 'resources/css/checkout.css']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/css/table.css']); ?>
    

</head>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Navigatiebalk -->
    <nav>
        <!-- Navigatielinks -->
    </nav>

    <!-- Hoofdinhoudssectie -->
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div> 
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\OrderFlow\resources\views/layouts/app.blade.php ENDPATH**/ ?>
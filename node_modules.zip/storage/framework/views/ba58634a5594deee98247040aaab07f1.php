<div>
    <!--[if BLOCK]><![endif]--><?php if($allowed): ?>
    <div class="container">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="category">
            <div class="category-header">
                <h2 id="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></h2>
            
            </div>
            <div class="items">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" class="menu-item-image">
                    <div class="item-info">
                        <div class="item-name"><?php echo e($item->name); ?></div>
                        <div class="item-description"><?php echo e($item->description); ?></div>
                        <div class="item-actions">
                            <div class="item-price">€<?php echo e(number_format($item->price, 2)); ?></div>
                            <button class="add-item-btn" onclick="addToCart(<?php echo e(json_encode($item)); ?>)">&#43;</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <?php else: ?>
    <!--[if BLOCK]><![endif]--><?php if (! ($latitude && $longitude)): ?>
    <?php else: ?>
    <div class="error-message">
        <h2>Er ging iets mis..</h2>
        <h3>Controleer het volgende en probeer het opnieuw:</h3>
        <p>U bent minder dan 1 kilometer van het restaurant verwijderd.</p>
        <p>U heeft geen vpn of andere applicaties die de locatie van uw apparaat kunnen beïnvloeden.</p>
        <p>U heeft locatie ingeschakeld op uw telefoon en/of in de browser.</p>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').setLocation(position.coords.latitude, position.coords.longitude);
                }, function(error) {
                    console.error("Error: " + error.message);
                });
            } else {
                alert("Geolocation wordt niet ondersteund door deze browser.");
            }
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            window.addEventListener('saveTableIdToSessionStorage', event => {
                var tableId = event.detail[0].tableId;
                sessionStorage.setItem('tableId', tableId);
            });
        });
    </script>
    <div class="cart-panel">
    </div>

    <script>
        let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

        function addToCart(item) {
            const existingItem = cart.find(cartItem => cartItem.id === item.id);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                item.quantity = 1;
                cart.push(item);
            }
            sessionStorage.setItem('cart', JSON.stringify(cart));
            updateCartPanel();
            updateCartCount();
        }

        function updateCartPanel() {
            const cartPanel = document.querySelector('.cart-panel');
            cartPanel.innerHTML = cart.map(item => `<div>${item.name} x ${item.quantity} - €${(item.price * item.quantity).toFixed(2)}</div>`).join('');
        }

        function updateCartCount() {
            const cartCount = document.getElementById('cart-count');
            cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0);
        }

        function redirectToCheckout() {
            sessionStorage.setItem('cart', JSON.stringify(cart));
            window.location.href = '/menu/afrekenen';
        }

        // Initial update on page load
        updateCartPanel();
        updateCartCount();

        document.addEventListener('livewire:load', function() {
            Livewire.on('cartUpdated', () => {
                cart = JSON.parse(sessionStorage.getItem('cart')) || [];
                updateCartPanel();
                updateCartCount();
            });
        });
    </script>
</div><?php /**PATH C:\laragon\www\OrderFlow\resources\views/livewire/check-location.blade.php ENDPATH**/ ?>
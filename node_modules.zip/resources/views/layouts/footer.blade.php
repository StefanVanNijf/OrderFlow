<div class="footer">
    QR Code Terras 2024 rechten
</div>
@extends('layouts.app')

@section('content')

@livewire('checkout-component')

@endsection


{{-- resources/views/menu/betaald.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Je hebt succesvol betaald</h1>
    <p>Je bestelling komt er zo snel mogelijk aan.</p>
</div>
@endsection
